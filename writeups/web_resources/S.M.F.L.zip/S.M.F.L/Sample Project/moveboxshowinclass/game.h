#ifndef GAME_H
#define GAME_H
#include <SFML/Graphics.hpp>
#include <vector>


class Game{
public:
    Game();
    void Draw();
    void run();
    void processEvents();
    void update();
    void render();

    sf::RectangleShape mybox;

private:
    sf::RenderWindow window;

};


#endif // GAME_H
