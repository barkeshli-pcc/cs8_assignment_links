#ifndef Z_WORK_REPORT_H
#define Z_WORK_REPORT_H
/*
    Features:
        -Note Implemented: Did not implement inputting of number of coins.
              Could not figure out how to ask for coin denomination AND
              number of coins in the same loop.
        -Implemented: inputting of coin denominations and calculating the total in
               Dollars has been implemented and tested.
        -Partly implemented: None

    Bugs     : features that are implemented are bug-free.

    Reflections:
        I started too late and was not able to spend as much time as I needed.
        inputting of numbers (and their validation) was too hard for me.


*/
#endif // Z_WORK_REPORT_H
