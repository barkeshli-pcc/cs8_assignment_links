#ifndef Z_OUTPUT_H
#define Z_OUTPUT_H
/*
***** ALL RESULTS ARE VERIFIED ******
//---------------------------------------------------------------------
// normal run:
//---------------------------------------------------------------------
This program will calculate the total value of coins.
[$] Dollar [H]alf [Q]uarter [D]ime [N]ickle [P]enny   [?]Menu   e[X]it
: $
: $
: h
: q
: d
: n
: p
: x
------------ RESULTS --------------------
Total Dollar value of your coins is: 2.91


//---------------------------------------------------------------------
// help:
//---------------------------------------------------------------------
This program will calculate the total value of coins.
[$] Dollar [H]alf [Q]uarter [D]ime [N]ickle [P]enny   [?]Menu   e[X]it
: $
: ?
[$] Dollar [H]alf [Q]uarter [D]ime [N]ickle [P]enny   [?]Menu   e[X]it
: n
: x
------------ RESULTS --------------------
Total Dollar value of your coins is: 1.05


//---------------------------------------------------------------------
// no input:
//---------------------------------------------------------------------
This program will calculate the total value of coins.
[$] Dollar [H]alf [Q]uarter [D]ime [N]ickle [P]enny   [?]Menu   e[X]it
: x
------------ RESULTS --------------------
Total Dollar value of your coins is: 0.00


//---------------------------------------------------------------------
// bad input:
//---------------------------------------------------------------------
This program will calculate the total value of coins.
[$] Dollar [H]alf [Q]uarter [D]ime [N]ickle [P]enny   [?]Menu   e[X]it
: h
: n
: d
: a
[a] is not a valid choice. Press [?] for help
: x
------------ RESULTS --------------------
Total Dollar value of your coins is: 0.65



*/
#endif // Z_OUTPUT_H
